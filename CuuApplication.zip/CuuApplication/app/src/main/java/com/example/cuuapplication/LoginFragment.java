package com.example.cuuapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginFragment extends Fragment {

    private EditText userEmailEditText, userPassEditText;
    private Button loginButton;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);

        userEmailEditText = rootView.findViewById(R.id.userEmail);
        userPassEditText = rootView.findViewById(R.id.userpass);
        loginButton = rootView.findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userEmail = userEmailEditText.getText().toString();
                String userPass = userPassEditText.getText().toString();

                // Example validation logic (replace with your actual validation)
                if (isValidCredentials(userEmail, userPass)) {
                    // Navigate to the home screen (implicit intent)
                    Intent intent = new Intent(getActivity(), HomeActivity.class);
                    startActivity(intent);
                } else {
                    // Show error message for invalid credentials
                    Toast.makeText(getActivity(), "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return rootView;
    }

    private boolean isValidCredentials(String email, String password) {
        // Example validation logic (replace with your actual validation)
        return email.equals("example@example.com") && password.equals("password123");
    }
}
