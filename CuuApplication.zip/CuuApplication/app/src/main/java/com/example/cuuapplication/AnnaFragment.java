package com.example.cuuapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.cuuapplication.Announcement;
import com.example.cuuapplication.AnnouncementsAdapter;

import java.util.ArrayList;
import java.util.List;

public class AnnaFragment extends Fragment {

    private RecyclerView recyclerView;
    private AnnouncementsAdapter adapter;
    private List<Announcement> announcementsList;

    public AnnaFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_anna, container, false);

        recyclerView = rootView.findViewById(R.id.recycler_view_announcements);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Populate static announcement data for testing
        announcementsList = new ArrayList<>();
        announcementsList.add(new Announcement("Changes in Academic Calendar", "\"Dear Students and Faculty,\n" +
                "\n" +
                "We would like to inform you about some important changes in the academic calendar for the Fall 2024 semester. Please take note of the following updates:\n" +
                "\n" +
                "Revised Semester Start Date: [New Start Date]\n" +
                "Semester Break Adjustments: [Details of Changes, if any]\n" +
                "Examination Period Modification: [New Examination Dates]\n" +
                "Other Schedule Adjustments: [Any additional schedule changes]\n" +
                "These adjustments have been made to ensure a smoother academic experience for everyone. We kindly request you to check the updated calendar on the university portal for detailed information.\n" +
                "\n" +
                "Thank you for your understanding and cooperation.\n" +
                "\n" +
                "Regards,."));
        announcementsList.add(new Announcement("Semester Exam Schedule", "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."));
        announcementsList.add(new Announcement(" Guest Lecture Announcement", "Title: \"Guest Lecture on Emerging Technologies in Computer Science\"\n" +
                "Description:\n" +
                "\"Dear Students and Faculty Members,\n" +
                "\n" +
                "We are delighted to invite you to a special guest lecture on 'Emerging Technologies in Computer Science' by Dr. [Guest Speaker's Name], an esteemed expert in the field. The lecture aims to provide insights into the latest advancements and trends shaping the future of technology.\n" +
                "\n" +
                "Date: [Date of the Lecture]\n" +
                "Time: [Start Time - 2:00 PM to 4:00 PM]\n" +
                "Venue: [Lecture Hall, Block D]\n" +
                "\n" +
                "This is a wonderful opportunity for all of us to expand our knowledge and engage in discussions with industry leaders. We encourage everyone to attend and make the most of this valuable learning experience.\n" +
                "\n" +
                "Kindly RSVP to confirm your attendance.\n" +
                "\n" +
                "Best regards,."));

        adapter = new AnnouncementsAdapter(announcementsList);
        recyclerView.setAdapter(adapter);

        return rootView;
    }
}
