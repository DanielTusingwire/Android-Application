package com.example.cuuapplication;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cuuapplication.Announcement;

import java.util.List;

public class AnnouncementsAdapter extends RecyclerView.Adapter<AnnouncementsAdapter.ViewHolder> {

    private List<Announcement> announcementsList;
    private int clickedPosition;

    public AnnouncementsAdapter(List<Announcement> announcementsList) {
        this.announcementsList = announcementsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_announcement, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Announcement announcement = announcementsList.get(position);
        holder.textTitle.setText(announcement.getTitle());
        holder.textDescription.setText(announcement.getDescription());
    }

    @Override
    public int getItemCount() {
        return announcementsList.size();
    }

    public int getClickedPosition() {
        return clickedPosition;
    }

    public void setClickedPosition(int clickedPosition) {
        this.clickedPosition = clickedPosition;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
        TextView textTitle, textDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.text_title);
            textDescription = itemView.findViewById(R.id.text_description);
            itemView.setOnCreateContextMenuListener(this);
        }
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
           menu.setHeaderTitle("Context Menu");

            menu.add(0,R.id.action_view_details, 0, "View Details").setOnMenuItemClickListener((MenuItem.OnMenuItemClickListener) this);

            menu.add(0,R.id.action_share, 0, "Share").setOnMenuItemClickListener((MenuItem.OnMenuItemClickListener) this);


        }

    }


}

