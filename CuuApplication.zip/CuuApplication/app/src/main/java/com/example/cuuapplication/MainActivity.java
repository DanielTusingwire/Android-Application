package com.example.cuuapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);



        registerButton = findViewById(R.id.button_register);
        registerButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, LoginFragment.class);
            startActivity(intent);
        });

        MaterialToolbar toolbar = findViewById(R.id.topAppbar);
        drawerLayout = findViewById(R.id.drawer_layout); // Corrected assignment
        navigationView = findViewById(R.id.nav_view); // Corrected assignment
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                menuItem.setChecked(true);
                drawerLayout.closeDrawer(GravityCompat.START);
                if (id == R.id.nav_announcements) {
                    replaceFragment(new AnnaFragment());
                } else if (id == R.id.nav_courses) {
                    Toast.makeText(MainActivity.this, "Courses is Clicked", Toast.LENGTH_SHORT).show();
                } else if (id == R.id.nav_grades) {
                    Toast.makeText(MainActivity.this, "Grades is Clicked", Toast.LENGTH_SHORT).show();
                } else if (id == R.id.nav_home) {
                    Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                    replaceFragment(new HomeFragment());
                } else if (id == R.id.nav_button_item){
                    openCuuapWebsite();
                }
                else {
                    return true;
                }

                return false;
            }
        });
    }

    public void onIndexSendButtonClicked (View v){
        Intent intent = new Intent(this, SecondActivity.class);

        String username = "John Doe";
        int age = 25;
        intent.putExtra("USERNAME_KEY", username);
        intent.putExtra("AGE_KEY", age);

        startActivity(intent);

    }

    private void replaceFragment (Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framelayout,fragment);
        fragmentTransaction.commit();

    }
    private  void openCuuapWebsite(){
        String url = "https://www.cavendish.ac.ug/";
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "No application can handle this request", Toast.LENGTH_SHORT).show();
        }
    }
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }




}